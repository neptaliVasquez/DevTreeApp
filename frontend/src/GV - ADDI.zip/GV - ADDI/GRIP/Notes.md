# GRIP URLs
## DEV and Stage URLs

[GRIP UI - DEV](https://cory.catalog-dev.grip-research.org/)
[Swagger dsds - DEV](https://cory.catalog-dev.grip-research.org/dsds/swagger/index.html) 
[Swagger dss - DEV](https://cory.catalog-dev.grip-research.org/dss/swagger/index.html) 

[GRIP Workspaces - Stage](https://wk-stagehyd.centralus.cloudapp.azure.com/swagger/index.html) 
[GRIP Workspaces - PROD](https://wk-gvtreadwbwk.westeurope.cloudapp.azure.com/swagger/index.html)

## GRIP CODE
[Catalog](https://dev.azure.com/global-research-platforms/GRIP/_git/Catalog)

## Videos with very helpful GRIP knowledge transfer
[Videos here](https://gatesventures.sharepoint.com/:f:/r/teams/GatesResearchImagingPlatformGRIP-Orchestration/Shared%20Documents/GRIP-Orchestration/Vendor%20Documents/Zuehlke/Transition/Catalog?e=5%3ac4771ca7c2724fe2b6d763663ef5bbc7&sharingv2=true&fromShare=true&at=9&xsdata=MDV8MDJ8TGF3cmVuY2UuU2V0aWVuQGV2YWx1ZXNlcnZlLmNvbXxjYTVlYzcwOGI0M2Q0NGI5N2IwNzA4ZGVkMGU3ZDU0NHwwNDgzYWU1MWE2Mjc0NjZlYTdkZGRlMmFjN2UxMjM4ZXwwfDB8NjM5MTc3ODkxMzk4NDk2OTYzfFVua25vd258VFdGcGJHWnNiM2Q4ZXlKRmJYQjBlVTFoY0draU9uUnlkV1VzSWxZaU9pSXdMakF1TURBd01DSXNJbEFpT2lKWGFXNHpNaUlzSWtGT0lqb2lUV0ZwYkNJc0lsZFVJam95ZlE9PXwwfHx8&sdata=MWRscWdwSEJqQ3h1OW5NZWVTWk5WenNjdDdIMWUyS01lSnBxazJ3cjk3bz0%3d)


# Points of contact
**Whitelist an IP:** Cory White, Praveen 
**Help with backend code:** Cory White, Edgar 
**Help with frontend code:** Neptali Vasquez




