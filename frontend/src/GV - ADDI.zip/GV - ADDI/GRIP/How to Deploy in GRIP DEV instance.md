# How to deploy in GRIP to dev instance

Note: This dev instance belongs to Cory, ask him first.

1. Push code changes to a branch 
2. On [Azure Devops Pipelines](https://dev.azure.com/global-research-platforms/GRIP/_build) search and click on `grip-publish`
3. Select your branch, and run: ![[Pasted image 20260630144954.png]]
4. Once this is finished click on the `deploy-organization` pipeline, select your branch and environment is `catalogdev` and organization is `cory`:![[Pasted image 20260630145121.png]]