
| Server Name                        | IP Address      | OS      | ENV  | URL                                            | Notes                                       |
| ---------------------------------- | --------------- | ------- | ---- | ---------------------------------------------- | ------------------------------------------- |
| FDSA Pipeline .222                 | 172.208.16.222  | Rocky   | dev  | https://rocky-dev.fdsaservices.com             | Commented in the pipeline, not in use       |
| FDSA UAT                           | 20.25.54.242    | Ubuntu  | qa   | https://fdsa-uat.fdsa-temp.com                 |                                             |
| FDSA GW Server 1.105               | 20.228.127.105  | Ubuntu  | prod | https://fdsa-gw.fdsaservices.com/              | Installed in prod mode but it's our PreProd |
| FDSA GW Server 2.161               | 13.83.87.161    | Rocky   | prod | https://fdsa-gw.fdsaservices.com/              | Installed in prod mode but it's our PreProd |
| FDSA Lic Svr Prod .243             | 4.227.139.243   | Ubuntu  | prod |                                                |                                             |
| Query Builder Dev .151             | 172.174.130.151 | Ubuntu  | dev  | https://qbt-dev.fdsaservices.com/              |                                             |
| Query Builder Staging .0           | 4.180.18.0      | Ubuntu  | qa   | http://qbt-staging.fdsaservices.com/           |                                             |
| QB-1 WS Prod .117                  | 68.219.177.117  | Ubuntu  | prod | https://fdsa-query-builder.alzheimersdata.org/ |                                             |
| QB-2 WS Prod .238                  | 40.68.223.238   | Ubuntu  | prod | https://fdsa-query-builder.alzheimersdata.org/ |                                             |
| QB-3 Prod .75                      | 20.86.131.75    | Ubuntu  | prod | https://fdsa-query-builder.alzheimersdata.org/ |                                             |
| QB-4 Prod .102                     | 20.224.59.201   | Ubuntu  | prod | https://fdsa-query-builder.alzheimersdata.org/ |                                             |
| ADDI Jump-2 Windows                | 20.106.200.185  | Windows | NA   | NA                                             |                                             |
| FDSA Support                       | 20.96.194.91    | Ubuntu  | prod | https://fdsa-support.fdsaservices.com/         |                                             |
| HAProxy 2 (Prod) .175              | 68.154.112.175  | Ubuntu  | NA   | NA                                             |                                             |
| FPCC - DIS VPN Proxy Server        | 9.163.234.246   | Ubuntu  | NA   | I don't know                                   |                                             |
| RTC LB FDSA Rocky 9-2 .236         | 20.163.171.236  | Rocky   | prod | I don't know                                   |                                             |
| faas.addi.alzheimersdata.org Svr 1 | 40.113.161.24   | Ubuntu  | prod | https://faas.addi.alzheimersdata.org/          |                                             |
| faas.addi.alzheimersdata.org Svr 2 | 20.54.248.75    | Ubuntu  | prod | https://faas.addi.alzheimersdata.org/          |                                             |
|                                    |                 | Rocky   | qa   | https://fdsa-rocky.fdsaservices.com/           | Missing in GateKeeper                       |
|                                    |                 | Ubuntu  | prod | https://qbt-pre-prod.fdsaservices.com/         | Missing in GateKeeper                       |
|                                    |                 | Ubuntu  | prod | https://qbt-pre-prod.fdsaservices.com/         | Missing in GateKeeper                       |

# FDSA Servers
## Dev
- FDSA Pipeline .222 - 172.208.16.222 - **Rocky DEV server** (https://rocky-dev.fdsaservices.com/admin). Note: Commented in the pipeline, not in use.
- Missing in GateKeeper - https://fdsa-dev.fdsaservices.com/admin (Note: Commented in the pipeline, not in use.)
Note: Pipeline installs at: `/home/gitaction/actions-runner/_work/federated-data-sharing-appliance/federated-data-sharing-appliance/federated-data-sharing-appliance-release`
## Staging
- FDSA UAT (fdsa-uat.fdsa-temp.c...) - 20.25.54.242
- Missing in GateKeeper - https://fdsa-rocky.fdsaservices.com/admin
Note: Pipeline installs at: `/home/gitaction/actions-runner/_work/federated-data-sharing-appliance/federated-data-sharing-appliance/federated-data-sharing-appliance-release`
## Preprod
- FDSA GW Server 1.105 - 20.228.127.105 - (UBUNTU)
- FDSA GW Server 2.161 - 13.83.87.161 - (ROCKY)
Note: Pipeline installs at: `/var/www/federated-data-sharing-appliance-releases`
## FDSA Licensing Server
- FDSA Lic Svr Prod .243 - 4.227.139.243

# Query Builder Servers
All QB instances are installed by the pipeline at:
`/home/gitaction/actions-runner/_work/fdsa-end-user-query-builder-tool-and-gateway/fdsa-end-user-query-builder-tool-and-gateway`
## Dev instances
- Query Builder Dev .151 - 172.174.130.151
## Staging
- Query Builder Staging .0 - 4.180.18.0
## Preprod
- Missing in GateKeeper - https://qbt-pre-prod.fdsaservices.com/qbt/
## Prod
- QB-1 WS Prod .117 - 68.219.177.117
- QB-2 WS Prod .238 - 40.68.223.238
- QB-3 Prod .75 - 20.86.131.75
- QB-4 Prod .102 - 20.224.59.201

# Others
## Windows Jumpbox
- ADDI Jump-2 Windows - 20.106.200.185
## FDSA Rocky
- RTC LB FDSA Rocky 9-2 .236 - 20.163.171.236
## Proxies and VPN
- HAProxy 2 (Prod) .175 - 68.154.112.175
- FPCC - DIS VPN Proxy Server - 9.163.234.246
## FDSA as a Service
- faas.addi.alzheimersdata.org Svr 1 - 40.113.161.24
- faas.addi.alzheimersdata.org Svr 2 - 20.54.248.75
## FDSA servers for demo/support/prod-testing
- FDSA Support - 20.96.194.91
