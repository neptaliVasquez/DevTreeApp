# URLs

## Helpful URLs
- Gatekeepr/Guacamole: [GateKeeper](https://guac2.fdsaservices.com/dashboard)
- FDSA Devops Boards: [Sprints - Boards](https://dev.azure.com/alzheimersdata-org/FDSA%20Development/_sprints/directory)
- [FDSA - ADDI DOCS](https://addiorg.sharepoint.com/teams/ADDI-EVSFDSAEngineeringTeam?CID=1cd8b6df-fc54-44b6-9c18-8734292076d9)

## FDSA URLs
- FDSA DEV: https://fdsa-dev.fdsaservices.com/admin
- FDSA QA/UAT: https://fdsa-uat.fdsa-temp.com/admin/
- FDSA Rocky QA: https://fdsa-rocky.fdsaservices.com/admin
- FDSA Rocky DEV: https://rocky-dev.fdsaservices.com/admin
- FDSA PROD: https://fdsa-gw.fdsaservices.com/admin/
- FDSA PROD Swagger Common APIs: https://fdsa-gw.fdsaservices.com/docs/common/
- FDSA PROD Swagger Admin APIs: https://fdsa-gw.fdsaservices.com/docs/admin/

## Query Builder (QB)
- QB Non Tabular Data: https://qb-ntd.fdsaservices.com/qbt/
- QB PROD: https://fdsa-query-builder.alzheimersdata.org/qbt/
- QB PreProd: https://qbt-pre-prod.fdsaservices.com/qbt/
- QB DEV: https://qbt-dev.fdsaservices.com/qbt/
- QB Staging: http://qbt-staging.fdsaservices.com/

## Data Interoperability Service (DIS)
- [Azure - grip-data-interop-service](https://portal.azure.com/#@gripresearch.onmicrosoft.com/resource/subscriptions/0fad945a-1804-4170-85ed-df8b3c950f38/resourceGroups/grip-data-interop-service/overview)
- [DID - DEV](https://dis-dev.alzheimersdata.org/docs)
- [DID - Staging](https://dis-staging.alzheimersdata.org/docs)
- [DIS - Pre prod](https://dis-pre-prod.alzheimersdata.org/docs)
- [DIS - PROD](https://dis-prod.alzheimersdata.org/docs)
- [PROD - DIS Selection Portal](https://adwb-ws-transfer.discover.alzheimersdata.org/)
- [DEV - DIS Selection Portal](https://witty-hill-0ae3b610f.3.azurestaticapps.net/)

## GRIP
- [GRIP Dev - Scrum Board - Jira](https://grip-research.atlassian.net/jira/software/projects/GRP/boards/113)
- [GRIP-CATALOG REPOSITORY](https://dev.azure.com/global-research-platforms/GRIP/_git/Catalog)
- [Stage AD Discovery Portal](https://stage.grip-research.org/)
- [Stage EPND](https://stage.epnd.org/)
- [ADWB PROD -> discover.alzheimersdata.org](https://discover.alzheimersdata.org/)
- [Stage - DSDS - Swagger UI](https://stage.grip-research.org/dsds/swagger/index.html)
- [Stage - DSS - Swagger UI](https://stage.grip-research.org/dss/swagger/index.html)
- [GRIP Keycloak DEV Administration Console](https://cory.catalog-dev.grip-research.org/login/admin/catalogdevcory/console/#/catalogdevcory/clients)

## Synapse/Stage
**Note**: Synapse/stage is a provider integrated with DIS already.

- [AD Knowledge Portal - PROD](https://adknowledgeportal.synapse.org/Explore/Data)
- [AD Knowledge Portal - STAGING](https://staging.adknowledgeportal.synapse.org/Explore/Data)
- [AD Knowledge Portal - Datasets](https://www.synapse.org/Synapse:syn2580853/files/)
- [Synapse REST API - Docs](https://rest-docs.synapse.org/rest/index.html)
- [Downloading Data Programmatically](https://help.synapse.org/docs/Downloading-Data-Programmatically.2003796248.html)
