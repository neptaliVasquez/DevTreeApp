# Docker
```sh
# Stop and remove dockers
docker stop $(docker ps -a -q)
docker rm $(docker ps -a -q)
docker volume rm $(docker volume ls -q)

# Three together
docker stop $(docker ps -a -q) && docker rm $(docker ps -a -q) && docker volume rm $(docker volume ls -q)

# Delete all images
docker rmi $(docker images -q)

# rm releases folder and zip
rm -r federated-data-sharing-appliance-*

# Docker logs tail
docker logs --tail 500 fdsa_api

# Remove everything
docker system prune -a

# Get logs into a file:
docker logs fdsa_api > fdsa_api_logs.txt


docker compose logs > logs.txt

```
# Pre-Commit & Isort
```sh
pre-commit run --all-files
```

---

# FDSA

## New installer commands
```
(Textual installer Install and upgrade)  bash installer.sh  
(Browser installer Install and upgrade)   bash installer.sh --webmode  
(CLI installer) bash installer.sh --textmode  
(CLI upgrade) bash installer.sh --textmode --update
```

## Update when creating new file
When a new file or library is added to the fdsa_backend directory, we need to update poetry like this.
```sh
# Needed at least once if poetry is not installed
pip install poetry
cd api/fdsa_backend && poetry build -f wheel; cd ../..
python3 -m pip uninstall fdsa_backend -y
python3 -m pip install api/fdsa_backend/dist/fdsa_backend-0.1.0-py3-none-any.whl
```

If getting an environment error:
```bash
python3 -m venv ~/.venvs/poetry
source ~/.venvs/poetry/bin/activate
pip install poetry
```
## Updating database
```sh 
# 1st - Uncomment the migrations line in the docker compose

# 2nd - Run the following command:
docker exec -ti fdsa_api bash -c 'flask db revision --autogenerate --message "Custom message"'
```

## tcpdump to check if FDSA is receiving DARs
```sh
tcpdump -i any host 51.123.14.112 or host 51.145.185.18 and port 443
```

## Check nginx logs from outside
```bash
docker exec -it fdsa_nginx sh -c "tail -f /usr/src/app/logs/nginx_access.log /usr/src/app/logs/nginx_error.log"
```

## Update table to add level
```
update datasets set dataset_level = 'level2';

{"license_code": "FDSA_Lic_BchJN2gxIOlvtniW4QpBDslODBQ", "expiration_date": "2023-01-04 15:20:05"}
```

## Login to test database
```sh
psql -h <hostname> -p <port> -U <username> -d <database_name>

psql -h fdsa_db -p 5432 -U test_dataset_user -d test_dataset
```

## UAT Server adding SSL certs
```sh
# Start super user
sudo su

# Go to directory where fdsa is running
cd /home/gitaction/actions-runner/_work/federated-data-sharing-appliance/federated-data-sharing-appliance/federated-data-sharing-appliance-release

# Copy the ssl certs
cp -f "/home/gitaction/ssl-certs/"* ./ssl-certs/

# Restart Nginx
docker restart fdsa_nginx
```

### Pre-prod Load Balancers
```sh
# fdsa_lb1_gitaction
cp -f "/home/gitaction/ssl-certs/"* /home/gitaction/actions-runner/_work/federated-data-sharing-appliance-releases/federated-data-sharing-appliance-releases/ssl-certs/

# fdsa_lb2_rocky_gitaction
actions-runner/_work/federated-data-sharing-appliance/federated-data-sharing-appliance/federated-data-sharing-appliance-release/ssl-certs
```

## When updating FDSA SMTP in one LB we have to run this command
```
docker compose restart
```

## How to stop and restart the LB servers
```

docker compose stop

docker compose -f docker-compose-external.yml start

docker restart fdsa_nginx

```

## Stop tracking whitelists folder
```sh
cd /var/www/federated-data-sharing-appliance-releases
git rm -r --cached "./whitelists/*"


git update-index --assume-unchanged "./whitelists/*"
```


# Databases
## How to check active and idle connections to the database
```
psql -h addi-postres-db-west-us.postgres.database.azure.com -U evsdev -d postgres
63Hx89Dq21wz!

SELECT * FROM pg_stat_activity;
SELECT COUNT(*) FROM pg_stat_activity;

SELECT * FROM pg_stat_activity WHERE datname = 'load_balancer';
SELECT COUNT(*) FROM pg_stat_activity WHERE datname = 'load_balancer';


SELECT pid, usename, client_addr, state , query_start, query
FROM pg_stat_activity 
WHERE datname = 'load_balancer';

```

## How to delete a schema
```sql
\c example_datasource

DROP SCHEMA big_data_one_table CASCADE;

```

## PSQL
```
psql -h fdsa_db -p 5432 -U username -d database
```

# Python and Venv


```bash
python -m venv myenv

source myenv/bin/activate

deactivate

```


# FDSA Install Dependencies
```
sudo su
```

## Docker and docker compose
```
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg


echo \
"deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
$(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list

apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
```

## Start Systemctl docker services
```
systemctl enable docker.service

systemctl enable containerd.service
```

## Other libaries
```
apt-get install -y apt-transport-https ca-certificates curl gnupg lsb-release neofetch postgresql-client telnet
```

# Validate Access Token on GRIP
```sh
curl -v -X 'GET' 'https://discover.alzheimersdata.org/dss/api/v1/recorddata/3fa85f64-5717-4562-b3fc-2c963f66afa6'  -H 'accept: application/json' -H 'Authorization: Bearer eyJhbGciOiJFUzM4NCIsInR5cCIgOiAiSldUIiwia2lkIiA6ICItOWhPQ3pwR0dHd0NXUW9IdE81cjU1Z2lXaDF1ajZRRFc3NFpDOUg5dHBFIn0.eyJleHAiOjE3NjAwMzI4NzcsImlhdCI6MTc2MDAzMjU3NywiYXV0aF90aW1lIjoxNzYwMDMwMzQ1LCJqdGkiOiJvbnJ0YWM6ZDJkODFkYTctZDkyYi1mZmQ2LTA0NmYtMTRiMDhiYWI5OGZjIiwiaXNzIjoiaHR0cHM6Ly9kaXNjb3Zlci5hbHpoZWltZXJzZGF0YS5vcmcvbG9naW4vcmVhbG1zL2Fkd2JsaXZlbWFpbiIsImF1ZCI6WyJiYWNrZW5kLXdvcmtzcGFjZXMiLCJiYWNrZW5kIl0sInN1YiI6IjE4YTJkOWRhLTllMjUtNGQxNS1iNWE4LTYyMTViNGFmMDZjMyIsInR5cCI6IkJlYXJlciIsImF6cCI6InVpIiwic2lkIjoiZDM4MTI0Y2UtY2MwOC00MmI1LWJjNjctMmY0NTg2YTEwNjc2IiwiYWNyIjoiMCIsImFsbG93ZWQtb3JpZ2lucyI6WyJodHRwczovL2Rpc2NvdmVyLmFsemhlaW1lcnNkYXRhLm9yZyIsImh0dHBzOi8vcWJ0LWRldi5mZHNhc2VydmljZXMuY29tIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJncmlwLXVzZXIiXX0sInJlc291cmNlX2FjY2VzcyI6eyJiYWNrZW5kLXdvcmtzcGFjZXMiOnsicm9sZXMiOlsidXNlcl9pbXBlcnNvbmF0aW9uIl19LCJiYWNrZW5kIjp7InJvbGVzIjpbInVzZXJfaW1wZXJzb25hdGlvbiJdfX0sInNjb3BlIjoib3BlbmlkIGdyaXAgcHJvZmlsZSBlbWFpbCIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJuYW1lIjoiTGF3cmVuY2UgU2V0aWVuIiwicHJlZmVycmVkX3VzZXJuYW1lIjoibGF3cmVuY2Uuc2V0aWVuQGV2YWx1ZXNlcnZlLmNvbSIsImdpdmVuX25hbWUiOiJMYXdyZW5jZSIsImZhbWlseV9uYW1lIjoiU2V0aWVuIiwiZW1haWwiOiJsYXdyZW5jZS5zZXRpZW5AZXZhbHVlc2VydmUuY29tIn0.oWcE_yz2sEAQUbT17y_jkuAXmYE4HPrG75PQ1AFJhriyGy54HN6vnJQPi20-ZLuLfotiAgztSKi2LBYgGpxQ3T5dT22iR_SYISCQ_VGRmddADgaRMa4eKFNJ8s6ZFJaJ'
```


# SSL Certs

Get ssl certs expiration dates:
```
openssl x509 -dates -noout -in <sslcert>
```

# Adding to Keycloak trusted cert file
```sh
# Copy the cert inside the container
docker cp epnd.ca.pem fdsa_keycloak:/opt/jboss/epnd.ca.pem

# Enter the container as root
docker exec -u 0 -it fdsa_keycloak bash

# Run the keytool command to trust the certificate
keytool -import -trustcacerts \
  -alias epnd-ca \
  -file /opt/jboss/epnd.ca.pem \
  -keystore /usr/lib/jvm/java-11-openjdk-11.0.16.0.8-1.el8_6.x86_64/lib/security/cacerts \
  -storepass changeit \
  -noprompt

# Verify the changes
keytool -list -v \
  -keystore /usr/lib/jvm/java-11-openjdk-*/lib/security/cacerts \
  -storepass changeit | grep epnd
  
# Exit the conainer
exit

# restart keycloak
docker restart fdsa_keycloak
```

