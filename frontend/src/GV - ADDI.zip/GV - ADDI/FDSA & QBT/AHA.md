
# SSO details for AHA
## Staging
```
addiClientId:  grip-backend-aha-token-exchange  
addiSecret :  3QyTIy7uT6HFF0ufqyfBcydlWv7OQlQd  
disDatasetUrl:  https://dis-staging.alzheimersdata.org/api/dis/v1  
disApiKey:  89b2cf91a875297f02221e2f47258c8561a92f6f933e94824ab88a0ec1e7e84e  
disAuthUrl:  https://stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/token  
disProvisionUrl:  https://stage.grip-research.org/dsds/api/v1/keycloak/provision  
SUBJECT_TOKEN_ISSUER: ahaqa
```
## Production
```
addiClientId:  grip-backend-aha-token-exchange  
addiSecret :  3QyTIy7uT6HFF0ufqyfBcydlWv7OQlQd  
disDatasetUrl:  https://dis-prod.alzheimersdata.org/api/dis/v1  
disApiKey:  oQeMBVr8M7ZR258ugHnFEygW6Tg3QBoHnoSniE247GlFcumOLx  
disAuthUrl:  https://discover.alzheimersdata.org/login/realms/adwblivemain/protocol/openid-connect/token  
disProvisionUrl:  https://discover.alzheimersdata.org/dsds/api/v1/keycloak/provision  
SUBJECT_TOKEN_ISSUER: aha
```


# Athena and Glue

## Useful commands to check glue connection
```bash
# EC2 instance role
docker exec -it fdsa_api python3 -m fdsa_backend.scripts.check_glue_access --region us-west-2 --instance-role --tables

# Named AWS profile mounted in container
docker exec -it fdsa_api python3 -m fdsa_backend.scripts.check_glue_access --region us-west-2 --profile my-profile

# Explicit access key/secret key
docker exec -it fdsa_api python3 -m fdsa_backend.scripts.check_glue_access --region us-west-2 --access-key AKIA... --secret-key ...
```