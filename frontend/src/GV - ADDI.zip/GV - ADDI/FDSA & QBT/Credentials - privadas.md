# FDSA Support
```sh
fdsa.support@alzheimersdata.org
```
# Test license
```
# Test
FDSA-Lic-iWU7wCdsJTmon9smN1aOH16VCHc

# With Hasura-Athena
FDSA_Lic_Jt3J0pn7t61WoOqbkp0LGJISwto
```
# FDSA and QB Encrypting pass
```
In FDSA:
ENCRYPTING_PASSWORD= 0b52b4a816318dce31052a9fbbea15e3f49d1738

In QB:
ENCRYPTING_PASSWORD='gCBiggxMzs52bj9Nx9GikKY43PkwWi5tSxbHd7LuRvywH7idqS2nj7vrrCDnbELMTTJYC2'
```
# Slack
```
SLACK_TOKEN='xoxb-5419524892915-6275010657154-88yTaQJXbEYe5xw92JfxsY0a'
SLACK_FDSA_CHANNEL_ID='C085Q3X4CEP'
SLACK_QB_CHANNEL_ID='C06A3319VFF'
```
# Server Credentials
```
User: fdsadev / Pass: 47hw23px39zq
User: evsdev / Pass: 63Hx89Dq21wz!
User: gitaction / Pass: 6£uYvc.62Sw}

UAT and Rocky-dev:                  0lfNger35EfUh9wAgAnf4sdRUg147Q
Ubuntu Demo:                        WqzELMxp1ItpmODqIOqR7J6MRtYTAP
fdsa-gw.addi-services.org:          sKCx9tfbfRmw2snkyxTOrPonNWXeNv
root - fdsa-gw.addi-services.org:   Qw7z1GB7OpDUIYWwv0tWSww08iH3FW
root - fdsa.addi-services.org:      angT9rylAi7bzDTHmVubu5YES3jRMI
qbt-new-gui.fdsaservices.com:       9hBz8TlrWdIWrpTbHSQTxGCzFGu5LW
root - fdsa-qa.fdsaservices.com:    19uPKtmOVz50C1NSwmEKyIWoKznGoo
fdsa-dev.fdsaservices.com:          9gfIBcrK23z28Ccl410zTvfPo8cUPi

### l2-appliance.fbhi.se
Server sudo su pass: eymDHV%12vlsHA
FDSA root Username: root
FDSA root Password: dwJrHV8099H4ivmW4dNqSohPcy7Lfd
FDSA root MFA seed: JIYUOSBRJFWE2YSCPJGEO33TGV4DKQKK

```
# SMTP Credentials
```sh
# Gmail credentials
MAIL_SERVER='smtp.gmail.com'
MAIL_PORT='587'
MAIL_DEFAULT_SENDER='fdsa.notify@gmail.com'
MAIL_USERNAME='fdsa.notify@gmail.com'
MAIL_PASSWORD='adgpvtenyzakxanp'
MAIL_USE_TLS='true'
MAIL_USE_SSL='false'
MAIL_DISPLAY_NAME='FDSA'
Password for UI login: fdsaNotify-2afbY8fIW
```
# Default DB
```
friendly_name: FDSA_TEST_DB
database_name: test_datasource
user: test_dataset_user
pass: test_dataset_pass
port: 5432
host: fdsa_db

Schema: test_dataset
```
# Athena
```
Region: us-west-2
aws_access_key_id: AKIAQ3EGQM7JSYADEO7M
aws_secret_access_key: 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
```
# Azure
## Database
```sh 
# Credentials 1
host: addi-postres-db-west-us.postgres.database.azure.com
database: load_balancer
user: load_balancer
password: load_balancer_pass

# Credentials 2
host: addi-postres-db-west-us.postgres.database.azure.com
database: example_dataset
user: load_balancer
password: load_balancer_pass
```
### FaaS-FDSA Database
```
psql "--host=grip-prod-fdsa-db-1.postgres.database.azure.com" "--port=5432" "--dbname=postgres" "--username=postgresadmin" "--set=sslmode=require"  

pass: k53&yh5IQXhE12!


SELECT
    pid,
    usename,
    application_name,
    client_addr,
    state,
    backend_start,
    query_start
FROM pg_stat_activity
ORDER BY backend_start;


SELECT usename,
       COUNT(*) AS connections
FROM pg_stat_activity
GROUP BY usename
ORDER BY connections DESC;

SHOW max_connections;


SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE state = 'idle'
  AND usename = 'postgresadmin';


```
##  Client Secret
```sh
os.environ['AZURE_CLIENT_ID']='885dc869-9a46-41ee-a5e8-6b9ef1566982'
os.environ['AZURE_TENANT_ID']='433331dc-3947-4877-9ef2-77465225c2c7'
os.environ['SUBSCRIPTION_ID']='8ce0fdcc-a792-4b30-bb4b-225b5742ccc1'
os.environ['AZURE_CLIENT_SECRET']='I0c8Q~V0TrbpC0ywGJtkwH4CeqT9KUD4~qA-hdc6'

# New Client Secrets
AZURE_CLIENT_SECRET = I0c8Q~V0TrbpC0ywGJtkwH4CeqT9KUD4~qA-hdc6
AZURE_CLIENT_SECRET = HmI8Q~DzuChtB44fM1gdRz1MvDzOauHKnDShHbCJ
```
## Registries
```sh
# Default/Legacy Registry Credentials
REGISTRY_ADDRESS='addiprodregistry1.azurecr.io'
REGISTRY_USERNAME='fdsa-addi-reg1'
REGISTRY_PASSWORD='ieTi1jZjOrx4kze13UA/CXhtP5t5cUkX'

# fdsaprodinstallers
REGISTRY_ADDRESS='fdsaprodinstallers.azurecr.io'

# docker login command
docker login -u FDSA-QA-Test -p 3vFQVQNlEF1yHvjO7iE0=5dEB0QN7j37 fdsaqainternal.azurecr.io

#
docker login -u FDSAPrivateRegistryPull -p YexuPd8nC/M8pIep0GI6BypTUk/CzjdpcvtERttNuJ+ACRDD2SVa  fdsaprivateregistry.azurecr.io

ACR_PASSWORD_DEVELOP: ZwTUPVGBuw2Q6aPDZC1iQ7OxhWIOQj7+84Z3k2MUgM+ACRD1Jp/D
ACR_PASSWORD_DEVELOP: m7YFBojeMNXWP2LLdMOLVpwDvhZeDUwWFOPb3YMXHu+ACRDgEFoL
```
# Legacy FAIR user
```sh
username: fair
password: WsSwSy61V8p*
```
# SSO Azure B2C 
```
# B2C Configuration
B2C_CLIENT_ID='251e0bec-7d2e-40ef-83d0-c6463f33abbf'
B2C_CLIENT_PASSWORD='KfL8Q~r9U5QXXhGuunBNZ~CNvHbM6hD1M1k.pbLU'
B2C_CLIENT_AUTHORITY='https://addib2c.b2clogin.com/addib2c.onmicrosoft.com/B2C_1_Signup_Signin'
B2C_SCOPES='openid email profile 251e0bec-7d2e-40ef-83d0-c6463f33abbf'

# Fair FDSA USER
FAIR_PASSWORD='WsSwSy61V8p*'
FAIR_BASE_URL='https://fair.addi.ad-datainitiative.org'
FAIR_STAGING_BASE_URL='https://fair-staging.addi.ad-datainitiative.org'
```
# Hasura
```
eyJhbGciOiJSUzI1NiIsImtpZCI6IjEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJIYXN1cmEiLCJzdWIiOiJwcmFiaHUuZ2FuZXNoYW5AYWx6aGVpbWVyc2RhdGEub3JnIiwiZXhwIjoxNzY0MjAxNjAwLCJpYXQiOjE3MzA0MDgxOTIsImp0aSI6IjE5OWZhMjY4LTcxZjMtNDc5MC1hYjlkLTA4NjA4NWY5MzYyNyIsImxpY2Vuc2VfZXhwX2F0IjoxNzY0MjAxNjAwLCJncmFjZV9leHBfYXQiOjE3NjQyMDE2MDAsImxpY2Vuc2VfdHlwZSI6InBhaWQifQ.MhfqqEWWG0rCBjaRPQYtULI0_bLTN8YLlZi-ZTcqGKDLklDKJobkm2mT36dFwA38kVQjQ8rOAevqweLiC-2Lh7ZiZvHwZoEB_0YDs1kmd0gAvjKjVXkNgZsdjsNbITU17GmlTrNuk95KM2wlv68mIKhkTuaB_LQaUSKkbJrqxtNtFAONTx2NAR64KpQKB-KmXnpijAvVr-6oVOV3HR5BbradHCSPY_eIIwJS_nBEsbCgCHj5ZBzAYAzmgUjOQPBXP1lYE_ZNozxMVD9lP2rAcr4NpSFBPe5M3LqO3qy25yUlvYjmP3mfYTS_84nh_rDfMakQztFXWv5RjIg7X_4ZPcZtHkreLWA3flazaHiQj1GYaaOY_cgQp4FsvQL4dI6YzGqtoM6hZWxMw3klQ7y4kw7AgP17QV7XdLlALqpKFWC3iUpz2wkLi3rCveNlU-IrPLpyjD-l_FDaSt6RaJ8FECDHLh6l6zStka7R_LLwUCqbbgf5JKsLyomeWzMwcbG3
```

# Identity providers:
## OLD, DEPRECATED
```
Authorization URL: 	https://keycloak.westeurope.addi.ad-datainitiative.org/auth/realms/DRE/protocol/openid-connect/auth
Token URL:		    https://keycloak.westeurope.addi.ad-datainitiative.org/auth/realms/DRE/protocol/openid-connect/token
User Info URL:		https://keycloak.westeurope.addi.ad-datainitiative.org/auth/realms/DRE/protocol/openid-connect/userinfo
Issuer:			    https://keycloak.westeurope.addi.ad-datainitiative.org/auth/realms/DRE
JWKS URL:		    https://keycloak.westeurope.addi.ad-datainitiative.org/auth/realms/DRE/protocol/openid-connect/certs
Client ID:		    workspaces
Client Secret:      cXi8Q~UF5q8ExI85RzkRhopvR_Dm6UZ4B1dd.ae6
```
## GRIP Hybrid Staging (OLD, DEPRECATED)
```
Authorization URL: 	https://hybrid-stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/auth
Token URL:		    https://hybrid-stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/token
User Info URL:		https://hybrid-stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/userinfo
Issuer:			    https://hybrid-stage.grip-research.org/login/realms/gripstagehybrid
JWKS URL:		    https://hybrid-stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/certs
Client ID:		    fdsa-sso
Client Secret:		Di4ghItTUL60HJUW7pIixWv2xB0H7jyS 
```
## GRIP ADWB - Staging
```
Authorization URL: 	https://stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/auth
Token URL:		    https://stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/token
User Info URL:		https://stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/userinfo
Issuer:			    https://stage.grip-research.org/login/realms/gripstagehybrid
JWKS URL:		    https://stage.grip-research.org/login/realms/gripstagehybrid/protocol/openid-connect/certs
Client ID:		    fdsa-sso
Client Secret:		Di4ghItTUL60HJUW7pIixWv2xB0H7jyS 
```
## GRIP ADWB - Prod
```
Authorization URL: 	https://discover.alzheimersdata.org/login/realms/adwblivemain/protocol/openid-connect/auth
Token URL:		    https://discover.alzheimersdata.org/login/realms/adwblivemain/protocol/openid-connect/token
User Info URL:		https://discover.alzheimersdata.org/login/realms/adwblivemain/protocol/openid-connect/userinfo
Issuer:			    https://discover.alzheimersdata.org/login/realms/adwblivemain
JWKS URL:		    https://discover.alzheimersdata.org/login/realms/adwblivemain/protocol/openid-connect/certs
Client ID:	        fdsa-sso
Client Secret:      deGlayzzgLdKXSpWEAXcHsdi3WhqMxna
```
## GRIP EPND - Staging
```sh
For now you can use https://stage.epnd.org. I have updated it to the latest code and added your callback urls.
Here’s the OpenID url: https://stage.epnd.org/login/realms/epndstagemain/.well-known/openid-configuration

Authorization URL:   https://stage.epnd.org/login/realms/epndstagemain/protocol/openid-connect/auth
Token URL:           https://stage.epnd.org/login/realms/epndstagemain/protocol/openid-connect/token
User Info URL:       https://stage.epnd.org/login/realms/epndstagemain/protocol/openid-connect/userinfo
Issuer:              https://stage.epnd.org/login/realms/epndstagemain
JWKS URL:            https://stage.epnd.org/login/realms/epndstagemain/protocol/openid-connect/certs
Client ID:           fdsa-sso
Client Secret:       YBQX2W30yqavfLFZYiW6O0HeneN3IJsY
```
## GRIP EPND - Prod
```
Authorization URL: 	https://discover.epnd.org/login/realms/epndmainlive/protocol/openid-connect/auth
Token URL:		    https://discover.epnd.org/login/realms/epndmainlive/protocol/openid-connect/token
User Info URL:		https://discover.epnd.org/login/realms/epndmainlive/protocol/openid-connect/userinfo
Issuer:			    https://discover.epnd.org/login/realms/epndmainlive
JWKS URL:		    https://discover.epnd.org/login/realms/epndmainlive/protocol/openid-connect/certs
Client ID:	        fdsa-sso
Client Secret:      YBQX2W30yqavfLFZYiW6O0HeneN3IJsY
```

# SSO QB Variables
## OLD
```
SSO_CLIENT_AUTHORITY='https://hybrid-stage.grip-research.org/'
SSO_REALM='gripstagehybrid'
SSO_CLIENT_ID='fdsa-sso'
SSO_SCOPES='openid grip roles'
SSO_CLIENT_SECRET='Di4ghItTUL60HJUW7pIixWv2xB0H7jyS'
SSO_SUBJECT_TOKEN_ISSUER='grip-research'
```
## DEV
```
DEV_ADWB_BASE_URL='https://stage.grip-research.org/'
DEV_ADWB_REALM='gripstagehybrid'
DEV_ADWB_CLIENT_ID='fdsa-sso'
DEV_ADWB_SCOPES='openid grip roles'
DEV_ADWB_CLIENT_SECRET='Di4ghItTUL60HJUW7pIixWv2xB0H7jyS'
DEV_ADWB_SUBJECT_TOKEN_ISSUER='grip-research'

DEV_EPND_BASE_URL='https://discover.epnd.org/'
DEV_EPND_REALM='epndmainlive'
DEV_EPND_CLIENT_ID='fdsa-sso'
DEV_EPND_SCOPES='openid email profile'
DEV_EPND_CLIENT_SECRET='YBQX2W30yqavfLFZYiW6O0HeneN3IJsY'
DEV_EPND_SUBJECT_TOKEN_ISSUER='grip-research'
```
## PROD
```
PROD_ADWB_BASE_URL='https://discover.alzheimersdata.org/'
PROD_ADWB_REALM='adwblivemain'
PROD_ADWB_CLIENT_ID='fdsa-sso'
PROD_ADWB_SCOPES='openid grip roles'
PROD_ADWB_CLIENT_SECRET='deGlayzzgLdKXSpWEAXcHsdi3WhqMxna'
PROD_ADWB_SUBJECT_TOKEN_ISSUER='https://discover.alzheimersdata.org/login/realms/adwblivemain'

PROD_EPND_BASE_URL='https://discover.epnd.org/'
PROD_EPND_REALM='epndmainlive'
PROD_EPND_CLIENT_ID='fdsa-sso'
PROD_EPND_SCOPES='openid grip roles'
PROD_EPND_CLIENT_SECRET='YBQX2W30yqavfLFZYiW6O0HeneN3IJsY'
PROD_EPND_SUBJECT_TOKEN_ISSUER='https://discover.epnd.org/login/realms/epndmainlive'
```

# FDSA System user
```
username: grip.system.user@email.com
password: u4AQn9WFTcW7QThkX18nZ
```
# FDSA ROOT Credentials
```
https://faas.addi.alzheimersdata.org
root: VmxRVfWquoHt1xx3g36q9oaNCZ3au4
```

