# Default payload
```json
{
    "request": {
        "reference": "19905",
        "project_code": "test2-00017",
        "project_name": "test2",
        "start_date": "2024-05-29T04:00:00.000",
        "end_date": "2024-06-08T04:00:00.000",
        "project_description": "test2",
        "purpose": "test2",
        "requester": {
            "email": "lawrence.setien@evalueserve.com",
            "name": "Lawrence Setien"
        },
        "callback_url": "NA",
        "dataset_reference": {
            "dataset_code": "a16d3137-a9cf-4cf0-bd46-571b20445f9f",
            "dataset_id": "a16d3137-a9cf-4cf0-bd46-571b20445f9f"
        }
    },
    "form": [
        {
            "name": "name_1",
            "value": 1
        },
        {
            "name": "name_2",
            "value": "text"
        }
    ]
}
```


# Payloads received - testing start and end date
## Same start and end date
```sh
[29/Oct/2024 17:42:33] || WARNING || {'request': {'reference': '306', 'project_code': 'test-same-dates-1', 'project_name': 'test-same-dates-1', 'start_date': '2024-10-29T03:00:00.000', 'end_date': '2024-10-29T03
:00:00.000', 'project_description': 'test-same-dates-1', 'purpose': 'test-same-dates-1', 'scopes': ['can_compute'], 'requester': {'email': 'lawrence.setien@evalueserve.com', 'name': 'Lawrence Setien'}, 'callback
_url': 'https://fair-staging.addi.ad-datainitiative.org/api/requests/test-same-dates-1', 'dataset_reference': {'dataset_code': 'staging_test_multi_table', 'dataset_id': 'cecfd383-88d6-4409-9989-ffe4ae1a4208'}}, 
'form': [{'name': 'name_1', 'value': 1}, {'name': 'name_2', 'value': 'text'}]}
```

## End date before start date
```sh
[29/Oct/2024 17:43:21] || WARNING || {'request': {'reference': '307', 'project_code': 'test-start-date-later', 'project_name': 'test-start-date-later', 'start_date': '2024-11-09T03:00:00.000', 'end_date': '2024-
10-29T03:00:00.000', 'project_description': 'test-start-date-later', 'purpose': 'test-start-date-later', 'scopes': ['can_compute'], 'requester': {'email': 'lawrence.setien@evalueserve.com', 'name': 'Lawrence Set
ien'}, 'callback_url': 'https://fair-staging.addi.ad-datainitiative.org/api/requests/test-start-date-later', 'dataset_reference': {'dataset_code': 'staging_test_multi_table', 'dataset_id': 'cecfd383-88d6-4409-99
89-ffe4ae1a4208'}}, 'form': [{'name': 'name_1', 'value': 1}, {'name': 'name_2', 'value': 'text'}]}
```

## One day of difference
```sh
[29/Oct/2024 17:48:48] || WARNING || {'request': {'reference': '308', 'project_code': 'test-1-day', 'project_name': 'test-1-day', 'start_date': '2024-10-29T03:00:00.000', 'end_date': '2024-10-30T03:00:00.000', '
project_description': 'test-1-day', 'purpose': 'test-1-day', 'scopes': ['can_compute'], 'requester': {'email': 'lawrence.setien@evalueserve.com', 'name': 'Lawrence Setien'}, 'callback_url': 'https://fair-staging
.addi.ad-datainitiative.org/api/requests/test-1-day', 'dataset_reference': {'dataset_code': 'staging_test_multi_table', 'dataset_id': 'cecfd383-88d6-4409-9989-ffe4ae1a4208'}}, 'form': [{'name': 'name_1', 'value'
: 1}, {'name': 'name_2', 'value': 'text'}]}
```

