Access as super user:
```sh
sudo su
```

Remove all containers and complete clean up:
```sh
# Stop and remove containers:
docker stop $(docker ps -a -q) && docker rm $(docker ps -a -q) && docker volume rm $(docker volume ls -q)

# Remove images:
docker rmi $(docker images -q)

# Remove all images and networks
docker system prune -a
```

Copy the certs  into a secure place:
```sh
cp -r /var/www/federated-data-sharing-appliance-releases/ssl-certs /var/www/ssl-certs-copy
```

Now remove the release project folder:
```sh
cd /var/www/

rm -r federated-data-sharing-appliance-releases
```

Clone the project and prepare env:
```sh
# Clone the release
git clone git@github.com:alzheimersdata-org/federated-data-sharing-appliance-releases.git

# Access the folder
cd federated-data-sharing-appliance-releases

# Copy the .env
cp .env-template .env

# Copy the certs into ssl-certs:
cp /var/www/ssl-certs-copy/* ./ssl-certs

```

**Optional**: Modify the .env (with vim or nano) so `ENV_MODE` variable looks like this:
```
ENV_MODE='qa'
```
> NOTE: When installing in QA mode the MFA won't be mandatory.

Install with the new installer:
```
bash installer.sh --textmode
```


