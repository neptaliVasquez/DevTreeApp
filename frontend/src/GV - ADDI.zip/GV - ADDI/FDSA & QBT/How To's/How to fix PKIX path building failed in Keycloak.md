> Note: This shouldn't be an issue anymore, the ssl certs are added to the FDSA keycloak during the build.
# Fixing `PKIX path building failed` in Keycloak (Java 11)

This document describes the exact steps followed to fix the following error in a **Keycloak Docker container**:

```
Caused by: sun.security.validator.ValidatorException: PKIX path building failed
Caused by: sun.security.provider.certpath.SunCertPathBuilderException: unable to find valid certification path to requested target
```

The issue was caused by **Java 11 not trusting the Sectigo Public Server Authentication Root R46 certificate**, which is used by `*.epnd.org`.

---

## Root Cause

* The TLS certificate chain of `discover.epnd.org` is valid and publicly trusted.
* The root CA **Sectigo Public Server Authentication Root R46** is **not included** in older Java 11 truststores.
* Keycloak (running on Java 11) fails TLS validation and throws a PKIX error.

---

## Environment

* Keycloak running inside Docker container: `fdsa_keycloak`
* Java version: **OpenJDK 11.0.16**
* OS inside container: RHEL / EL8-based

---

## Step-by-Step Fix (Option A: Import Root CA into Java truststore)

### 1. Create the Sectigo R46 root certificate (on host)

Create a file called `sectigo-r46.pem` containing **only the root certificate**:

```bash
cat > sectigo-r46.pem <<'EOF'
-----BEGIN CERTIFICATE-----
MIIFijCCA3KgAwIBAgIQdY39i658BwD6qSWn4cetFDANBgkqhkiG9w0BAQwFADBf
MQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMTYwNAYDVQQD
Ey1TZWN0aWdvIFB1YmxpYyBTZXJ2ZXIgQXV0aGVudGljYXRpb24gUm9vdCBSNDYw
HhcNMjEwMzIyMDAwMDAwWhcNNDYwMzIxMjM1OTU5WjBfMQswCQYDVQQGEwJHQjEY
MBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMTYwNAYDVQQDEy1TZWN0aWdvIFB1Ymxp
YyBTZXJ2ZXIgQXV0aGVudGljYXRpb24gUm9vdCBSNDYwggIiMA0GCSqGSIb3DQEB
AQUAA4ICDwAwggIKAoICAQCTvtU2UnXYASOgHEdCSe5jtrch/cSV1UgrJnwUUxDa
...
QGL
-----END CERTIFICATE-----
EOF
```

---

### 2. Copy the certificate into the Keycloak container

```bash
docker cp sectigo-r46.pem fdsa_keycloak:/tmp/sectigo-r46.pem
```

---

### 3. Enter the container as **root**

```bash
docker exec -it -u root fdsa_keycloak bash
```

Verify:

```bash
whoami
# expected: root
```

---

### 4. Confirm Java installation

```bash
ls /usr/lib/jvm
```

Observed Java path:

```
/usr/lib/jvm/java-11-openjdk-11.0.16.0.8-1.el8_6.x86_64
```

---

### 5. Import the certificate into the Java truststore

**Important:** Use `-cacerts` to avoid permission issues.

```bash
keytool -importcert -noprompt \
  -alias sectigo-r46 \
  -file /tmp/sectigo-r46.pem \
  -cacerts \
  -storepass changeit
```

Expected output:

```
Certificate was added to keystore
```

---

### 6. Verify the certificate is installed

```bash
keytool -list -cacerts -storepass changeit | grep -i sectigo
```

Expected output:

```
sectigo-r46, trustedCertEntry
```

---

### 7. Restart Keycloak

```bash
exit
docker restart fdsa_keycloak
```

---

## Result

* Java truststore now trusts Sectigo R46
* Keycloak TLS connections succeed
* `PKIX path building failed` error is resolved

---

## Important Notes (Production)

⚠️ **This change is not persistent if the container is recreated.**

### Recommended permanent solutions:

* Bake the certificate into a custom Keycloak Docker image
* Or mount a custom Java truststore
* Or upgrade to a newer Java version that includes Sectigo R46

---

## Summary

| Item  | Value                                     |
| ----- | ----------------------------------------- |
| Error | PKIX path building failed                 |
| Cause | Missing Sectigo R46 in Java 11 truststore |
| Fix   | Import root CA using `keytool -cacerts`   |
| Scope | Keycloak Docker container                 |

---

**Status:** ✅ Fixed
