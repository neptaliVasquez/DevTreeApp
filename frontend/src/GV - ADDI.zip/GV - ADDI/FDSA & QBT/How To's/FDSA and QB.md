# How to test a fresh install from Pre-production
1. Go to the installation directory
```bash
sudo su
cd /var/www/fede...
```
2. Switch to the `preproduction` branch
3. Change the registry from where the images are pulled
```bash
sed -i "s|^ACR_REGISTRY=.*|ACR_REGISTRY='fdsaqainternal.azurecr.io'|" .env

docker login -u FDSA-QA-Test -p 3vFQVQNlEF1yHvjO7iE0=5dEB0QN7j37 fdsaqainternal.azurecr.io
```
4. Install `bash ubuntu-startup.sh <FQDN>`

# How to test an upgrade in Pre-production
1.- Run a normal installation as it is instructed in the documentation (from main branch on the releases repository).
2.- Switch to the `preproduction` branch
3.- Update the `ACR_REGISTRY` variable in the .env:
```sh
sed -i "s|^ACR_REGISTRY=.*|ACR_REGISTRY='fdsaqainternal.azurecr.io'|" .env
```
4.- Make sure to be logged to the registry:
```sh
docker login -u FDSA-QA-Test -p 3vFQVQNlEF1yHvjO7iE0=5dEB0QN7j37 fdsaqainternal.azurecr.io
```
5.- Run the upgrade script: `bash change-version.sh`


# Test upgrade from 2.1.19 to 2.2.4

Install previous version 2.1.19:
```
# 1. Sudo su
sudo su

# 2. Go to installation dir
cd /var/www/

# 3. Clone the project
git clone git@github.com:alzheimersdata-org/federated-data-sharing-appliance-releases.git

# 4. Go to project dir
cd federated-data-sharing-appliance-releases

# 5. Checkout to previous version
git checkout 2.1.19

# 6. Copy the .env
cp .env-template .env

# 7. Copy the certs
cp ../self-signed-ssl-certs/* ./ssl-certs/

# 8. Install
bash ubuntu-startup.sh fdsa-lb-demo.fdsaservices.com
```

Upgrade to latest version:
```
# Checkout to main
git checkout main

# Run the upgrade script:
bash change-version.sh
```

# How to FDSA and QB Ubuntu Requirements
```sh
# Pip
apt install python3-pip

# Docker and Docker Compose
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

echo \
    "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
    $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list

apt-get update -y
apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin 

# Enabling docker
systemctl enable docker.service
systemctl enable containerd.service

# Installing Jq
apt install -y jq 
jq --version
```


# How to Install QB in prod mode from code
1. Clone the project at `/var/www`
2. cd to the project folder
3. `cp .env-template .env`
4. Replace every localhost in the .env with the FQDN (e.g: qb-ntd.fdsaservices.com)
5. Add the `fullchain_certfile.crt & private_keyfile.key` to the `ssl-certs` folder.
6. Install QB requirements:
```sh

	# Docker login
	docker login -u FDSA-Production-Install-Pull -p McwQS4Qzx2IlHif3S5l6Bhrdaro8b/fq fdsaprodinstallers.azurecr.io
	
	# Pip
	apt install python3-pip
	
	# Docker and Docker Compose
	curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
	
	echo \
	    "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
	    $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list
	
	apt-get update -y
	apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin 
	
	# Enabling docker
	systemctl enable docker.service
	systemctl enable containerd.service
	
	# Installing Jq
	apt install -y jq 
	jq --version
```
7. Run the project: `bash install.sh`



# Keycloak
## How to disable MFA
### Disabling user OTP/MFA
1. Login to Keycloak with root credentials (superadmin role)
2. Go to the `Users` tab -> Click on the `username`
3. Make sure in `Required user actions` there is no `Configure OTP` selected.
4. Go to the `Credentials` tab in the user view.
5. If there is a OTP configured, click on the actions and delete it.
### Disabling browser OTP/MFA
1. In the left column, go to `Authentication`
2. Click on `Required actions` tab -> Disable `Configure OTP`
3. Click on `Flows` tab -> Click on `Browser` -> Disable `Browser - Conditional OTP`
## How to make an admin superadmin
1. Login to Keycloak UI with root credentials
2. Click on the Users tab
3. Click on the user
4. Go to roles tab and add the following roles:
	- Administrator (fdsa-app)
	- Admin
	- Superadmin (fdsa-app)


# How to install from an image in the dev Registry
```
## 0. Check tag version on pipeline
In github actions step `set dev registry + version`

## 1. Modify .env 
CHANGE VERSION in .env to the one from previous step
CHANGE REGISTRY TO :
ACR_REGISTRY='fdsaqainternal.azurecr.io'

## 2. Login to dev registry  
docker login -u FDSA-QA-Test -p ZwTUPVGBuw2Q6aPDZC1iQ7OxhWIOQj7+84Z3k2MUgM+ACRD1Jp/D fdsaqainternal.azurecr.io

## 3. Re build containers  
docker compose pull  
docker compose up -d
```

# How to reset ROOT User MFA 
```
## 1. Access DB container
docker exec -it fdsa_api bash  

## 2 Access Keycloak DB
psql -U <pguser> -d <keycloak>

## 3. Identify root user ID
SELECT id, username  
FROM user_entity  
WHERE username = 'root';

## 4. Remove OTP from user
DELETE FROM credential  
WHERE user_id='<USER_ID>'  
  AND type='otp';
```


