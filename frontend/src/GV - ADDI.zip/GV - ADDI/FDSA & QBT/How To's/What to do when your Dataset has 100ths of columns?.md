**Context:**
The maximum number of columns per table supported by PostgreSQL is 1600.
This is why if you have a dataset with 100ths of coulmns it needs to be splitted into multiple tables.






# 1. Create a Datasource and Dataset in PostgreSQL

 1. Login to your database server as root user (or whatever admin user you have) 
```sh
psql -h <HOST IP/url> -p <PORT> -U <user> postgres 
```
   
2. Create a new user (the one we are going to use to add the DB to FDSA)
```sh
CREATE USER <username> WITH PASSWORD '<password>';

Note: The <username> and <password> used here are the ones required when adding a Data Source in FDSA. 
```

3. Give access to the new user
```sh
ALTER USER <username> CREATEDB; ALTER USER <username> CREATEROLE; 
```    

4. Exit and login with the new user:
```
\q

psql -h <HOST IP/url> -p <PORT> -U <username> postgres 
```    

5. As “username”, create the data source DB and switch to it.
```sh
CREATE DATABASE <test-database>;

\c <test-database> 
```

6. Then create a schema/dataset and add your research data there:
```sh
CREATE SCHEMA <test-dataset>;
```
IMPORTANT: Additionally, add tables with their respective columns, foreign keys, primary keys, and indexes in this schema, this is required to be able to execute queries/tasks with joins from the Query Builder Tool. The maximum size supported for sachems/datasets is 500 MB. 
 
NOTE: Replace every field that has ‘<>’ with your own values.


# 2. Split your CSV into multiple ones

1. Install the required libraries:
```sh
pip install pandas
```

2. You can use this Python code:
```python
import pandas as pd
import os

# Load the CSV file into a DataFrame
file_path = 'large_dataset.csv'
df = pd.read_csv(file_path)

# Define the primary key column
primary_key = 'your_primary_key_column_name'

# Ensure the primary key is in the DataFrame
if primary_key not in df.columns:
    raise ValueError(f"Primary key column '{primary_key}' not found in the dataset.")

# Create output directory for split CSV files
output_dir = 'split_csvs'
os.makedirs(output_dir, exist_ok=True)

# Determine the number of splits needed
columns_per_split = 1300
total_columns = len(df.columns)
num_splits = (total_columns - 1) // (columns_per_split - 1) + 1  # -1 to exclude primary key column

# Split and save the CSV files
for i in range(num_splits):
    start_idx = i * (columns_per_split - 1)  # Exclude primary key from count
    end_idx = min(start_idx + (columns_per_split - 1), total_columns - 1)

    # Select the subset of columns, including the primary key
    split_df = df[[primary_key] + df.columns[start_idx + 1:end_idx + 1].tolist()]
    split_file_path = os.path.join(output_dir, f'split_{i + 1}.csv')
    split_df.to_csv(split_file_path, index=False)
    print(f"Saved {split_file_path}")

```

# 3. Upload the CSV to PostgreSQL

1. Install the required libraries:
```sh
pip install pandas sqlalchemy psycopg2-binary
```

2. You can use this Python code:
```python

import os
import pandas as pd
from sqlalchemy import create_engine

# Define your PostgreSQL database credentials
db_username = '<username>'
db_password = '<password>'
db_host = '<db_host>'
db_port = '5432'
db_name = '<test-database>'

# Create a SQLAlchemy engine
engine = create_engine(f'postgresql+psycopg2://{db_username}:{db_password}@{db_host}:{db_port}/{db_name}')

# Path to the folder containing the CSV files
csv_folder_path = '/path/to/your/csv/folder'

# Define the primary key column shared by all CSV files
primary_key_column = 'your_primary_key_column'

# Iterate through each CSV file in the folder
for csv_file in os.listdir(csv_folder_path):
    if csv_file.endswith('.csv'):
        file_path = os.path.join(csv_folder_path, csv_file)

        # Read the CSV file into a pandas DataFrame
        df = pd.read_csv(file_path)

        # Extract table name from CSV file name (you can customize this)
        table_name = os.path.splitext(csv_file)[0]

        # Upload the DataFrame to PostgreSQL
        # If_exists='replace' will drop the table if it already exists
        # If_exists='append' will add data to an existing table
        df.to_sql(table_name, engine, if_exists='replace', index=False)

        # Add primary key constraint if the table was just created
        with engine.connect() as conn:
            conn.execute(f'ALTER TABLE "{table_name}" ADD PRIMARY KEY ("{primary_key_column}");')

        print(f"Uploaded '{csv_file}' as table '{table_name}' with primary key '{primary_key_column}'.")

print("All CSV files have been uploaded successfully.")
```
