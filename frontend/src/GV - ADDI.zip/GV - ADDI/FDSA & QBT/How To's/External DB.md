1. Go to Guacamole and login to `carlos_wsl_dev_jumpbox`.
2. Open `DBeaver`, the connection to the `load_balancer` is already there.
3. Hasura needs extention `pgcrypto` in Postgres DB. This is checked on `utils_check_postgres.sh`.

Keycloak database, 
![[Pasted image 20250624141028.png]]
```
flask db
```
