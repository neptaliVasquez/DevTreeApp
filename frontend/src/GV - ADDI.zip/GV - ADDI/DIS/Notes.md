# SQL Lite Commands

```bash
#Access the DB:
sqlite3 /app/data/grip_data_interop.db


.tables              # List all tables
.schema              # Show schema for all tables
.schema table_name   # Show schema for specific table
.quit                # Exit SQLite
```

```sql
-- Calculate total download time
SELECT 
  request_id,
  total_file_count,
  created_at AS start_time,
  updated_at AS completion_time,
  CAST((julianday(updated_at) - julianday(created_at)) * 86400 AS INTEGER) AS duration_seconds,
  status
FROM grip_file_download_requests
WHERE request_id = 'e8b526af-0b18-437c-a5a0-685c20e90aa5';

-- Analyze file-level performance
SELECT 
    file_name,
    file_id,
    created_at as file_start,
    updated_at as file_completion,
    CAST((julianday(updated_at) - julianday(created_at)) * 86400 AS INTEGER) as file_duration_seconds,
    retry_count,
    status,
    error_details
FROM grip_file_download_request_items 
WHERE request_id = 'bbe1bf5c-436f-4f0d-a212-a4fa2520bafd'
ORDER BY created_at;
```

