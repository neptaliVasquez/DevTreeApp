# Azure
## Subscription & Resource Group
```
# Subscription Name
GRIP - ADRC

# Subscription ID
0fad945a-1804-4170-85ed-df8b3c950f38

# Tenant ID
05f45800-5ca8-44f5-a8a7-ab806010060c

# Resource Group
grip-data-interop-service
```
## Key Vault
```bash
Key Vault:
- grip-dis-keyvault-shared
  
Required .env vars:
AZURE_CLIENT_ID=09d38326-808b-4052-acdc-6898433dcfac
AZURE_CLIENT_SECRET=PBv8Q~004PMIi9pO525LHWrlf~y2qRl0BYzuDc7Z
AZURE_TENANT_ID=05f45800-5ca8-44f5-a8a7-ab806010060c
AZURE_KEY_VAULT_URL=https://grip-dis-keyvault-shared.vault.azure.net/

DIS_PLATFORM_API_KEY=89b2cf91a875297f02221e2f47258c8561a92f6f933e94824ab88a0ec1e7e84e

```
## Storage
```txt
# Azure Storage - File Share URL
gripAzureStorageURL: https://blobdisdev.file.core.windows.net/dis-file-share
gripAzureStorageToken: ?sv=2024-11-04&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2026-04-02T02:46:30Z&st=2025-09-05T19:31:30Z&spr=https&sig=9EzgS4k198izFq8yYsASmtAuC2vPFrZZ%2FieJp4PnFpY%3D

# Azure Storage - Blob URL:
gripAzureStorageURL: https://blobdisdev.blob.core.windows.net/development
gripAzureStorageToken: ?sp=racwdli&st=2025-08-20T20:15:37Z&se=2025-11-08T03:30:37Z&sv=2024-11-04&sr=c&sig=iv7ObpXzXRZACYB1V%2F6AFLmXCBMVX5aQA9nTnZM7bpY%3D

# Azure Storage - Blob URL - internalfiles
AZURE_CATALOG_STORAGE_URL: https://blobdisdev.blob.core.windows.net/internalfiles
AZURE_CATALOG_STORAGE_SAS: ?sp=racwdli&st=2025-09-17T15:42:01Z&se=2030-09-18T00:57:01Z&spr=https&sv=2024-11-04&sr=c&sig=s0yb5V8o4LTBegF82TDqhpVy9cxyU8O%2BHw%2FETh%2BQQrQ%3D

# New Token
?sv=2024-11-04&ss=bfqt&srt=sco&sp=rwlacuptfx&se=2027-06-01T04:08:10Z&st=2025-11-17T18:53:10Z&spr=https&sig=hrlrmQqYrp3Ol5NgT4L198O20LaFDO9RLRSKIuXDkmU%3D
```
## PostgreSQL
```
DB_HOST=dis-postgres-shared.postgres.database.azure.com
DB_PORT=5432
DB_USERNAME=grip_admin
DB_PASSWORD=qKP7HpVGAFFKpTkp
DB_NAME=grip_data_interop_staging
DB_SSL_MODE=require
```
# API-X-KEY  /  DIS_PLATFORM_API_KEY
Dev, Staging and Preprod:
```
89b2cf91a875297f02221e2f47258c8561a92f6f933e94824ab88a0ec1e7e84e
```
Prod API Key:
```
oQeMBVr8M7ZR258ugHnFEygW6Tg3QBoHnoSniE247GlFcumOLx
```
Providers/Admin APIs  (All env modes):
```
DIS-PROVIDERS-API-SECRET: KxgYdW6zanFKdEgYtrR0J7WfD5GviRediP1daA8DDfZ0yNat7K
```
# HDRUK
```
HDRUK_PERSONAL_ACCESS_TOKEN: 67a7d2fdc6b309e4e647289931a1641d83f55a151ca17121f86853cab733f7cc
```

# CI/CD
```
TENANT_ID="05f45800-5ca8-44f5-a8a7-ab806010060c"
RESOURCE_GROUP="grip-data-interop-service"
LOCATION="eastus2"
ACR_NAME="gripdatainteropacr"
CONTAINER_ENV_NAME="dis-container-env"

ACR_USERNAME = gripdatainteropacr
ACR_PASSWORD = 5BunNAyv4q+R7YsvG/egh0uyS6vUgqPfFkFrLVCRXE+ACRAqoi8L
SUBSCRIPTION_ID=0fad945a-1804-4170-85ed-df8b3c950f38 

Application/Client ID 'grip-data-interop-cicd' = 51f2e4ea-eceb-4c77-af96-f6790be68701
```

# FDSA Variables
```
DAR Credentials
"email": "fair@aridhia.com",
"username": "fair",
"password": "WsSwSy61V8p*"
```

# Synape OAuth Client
```
Client ID: 100438
Client secret: D56CMto97Kds5ewwUdFTlp4eGSxrT6at2LcEWp2aKp0
```
# Redirect URIs endpoints
```
https://dis-backend.purplesand-eed15ff9.eastus.azurecontainerapps.io/api/auth/sage/callback
https://adwbtest.studycatalog.tech/catalogue/access-requests/callback/sage
https://adrcdemo.studycatalog.tech/catalogue/access-requests/callback/sage
https://hybrid-stage.grip-research.org/catalogue/access-requests/callback/sage
https://grip.catalog-dev.grip-research.org/catalogue/access-requests/callback/sage
https://discover.alzheimersdata.org/catalogue/access-requests/callback/sage

In test:
https://witty-hill-0ae3b610f.3.azurestaticapps.net/portal/api/auth/sage/callback
https://victorious-stone-0fe9de30f.3.azurestaticapps.net/portal/api/auth/sage/callback
https://adwb-ws-transfer.discover.alzheimersdata.org/portal/api/auth/sage/callback

```

# Selection Portal

Redirect URIs
```
- Staging: https://victorious-stone-0fe9de30f.3.azurestaticapps.net/auth/callback
- Production: https://adwb-ws-transfer.discover.alzheimersdata.org/auth/callback
```