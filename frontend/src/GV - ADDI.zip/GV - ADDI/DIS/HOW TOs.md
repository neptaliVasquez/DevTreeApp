# HOW to see DIS logs:

Details on this video: [how_to_see_DIS_logs.mkv](https://addiorg.sharepoint.com/:v:/r/teams/ADDI-EVSFDSAEngineeringTeam/Shared%20Documents/General/DIS/how_to_see_DIS_logs.mkv?csf=1&web=1&e=Er6ynW)
